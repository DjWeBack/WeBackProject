package messenger._protocol;

public class Server {
	public static final String IP ="localhost";
}
