SELECT * FROM room

SELECT * FROM room_member

SELECT * FROM chat

SELECT * FROM FRIEND

SELECT * FROM member 