DROP TABLE SCOTT.FRIEND CASCADE CONSTRAINTS;

CREATE TABLE SCOTT.FRIEND
(
  FRI_SEQ      NUMBER(10)                       NOT NULL,
  FRI_NO       NUMBER(5)                        NOT NULL,
  MEM_NO       NUMBER(5)                        NOT NULL,
  FRIEND_NAME  VARCHAR2(50 BYTE)
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


ALTER TABLE SCOTT.MEMBER
 DROP PRIMARY KEY CASCADE;

DROP TABLE SCOTT.MEMBER CASCADE CONSTRAINTS;

CREATE TABLE SCOTT.MEMBER
(
  MEM_NO          NUMBER(5)                     NOT NULL,
  MEM_ID          VARCHAR2(20 BYTE)             NOT NULL,
  MEM_NAME        VARCHAR2(20 BYTE)             NOT NULL,
  MEM_NICK        VARCHAR2(100 BYTE),
  MEM_GENDER      VARCHAR2(2 BYTE)              NOT NULL,
  MEM_PW          VARCHAR2(20 BYTE)             NOT NULL,
  MEM_HP          VARCHAR2(20 BYTE),
  MEM_PROFILE     VARCHAR2(200 BYTE)            DEFAULT 'profile_0.png',
  MEM_BACKGROUND  VARCHAR2(200 BYTE)            DEFAULT 'background_0.jpg'
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


ALTER TABLE SCOTT.ROOM
 DROP PRIMARY KEY CASCADE;

DROP TABLE SCOTT.ROOM CASCADE CONSTRAINTS;

CREATE TABLE SCOTT.ROOM
(
  ROOM_NO         NUMBER(5)                     NOT NULL,
  ROOM_STARTTIME  VARCHAR2(20 BYTE),
  ROOM_TITLE      VARCHAR2(100 BYTE)
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


ALTER TABLE SCOTT.ROOM_MEMBER
 DROP PRIMARY KEY CASCADE;

DROP TABLE SCOTT.ROOM_MEMBER CASCADE CONSTRAINTS;

CREATE TABLE SCOTT.ROOM_MEMBER
(
  ROOM_SEQ  NUMBER(10)                          NOT NULL,
  ROOM_NO   NUMBER(5)                           NOT NULL,
  MEM_NO    NUMBER(5)                           NOT NULL
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX SCOTT.FRI_OVERLAP_PK ON SCOTT.FRIEND
(MEM_NO, FRI_NO)
LOGGING
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX SCOTT."XPK��" ON SCOTT.ROOM
(ROOM_NO)
LOGGING
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX SCOTT."XPK��������" ON SCOTT.ROOM_MEMBER
(ROOM_SEQ)
LOGGING
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX SCOTT."XPKȸ��" ON SCOTT.MEMBER
(MEM_NO)
LOGGING
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE OR REPLACE TRIGGER SCOTT.tD_member AFTER DELETE ON SCOTT.MEMBER for each row
-- ERwin Builtin Trigger
-- DELETE trigger on member
DISABLE
DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin Trigger */
    /* member  room_member on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="0002e50f", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_17_1", FK_COLUMNS="mem_no" */
    UPDATE room_member
      SET
        /* %SetFK(room_member,NULL) */
        room_member.mem_no = NULL
      WHERE
        /* %JoinFKPK(room_member,:%Old," = "," AND") */
        room_member.mem_no = :old.mem_no;

    /* ERwin Builtin Trigger */
    /* member  friend on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="friend"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_18_1", FK_COLUMNS="mem_no" */
    UPDATE friend
      SET
        /* %SetFK(friend,NULL) */
        friend.mem_no = NULL
      WHERE
        /* %JoinFKPK(friend,:%Old," = "," AND") */
        friend.mem_no = :old.mem_no;

    /* ERwin Builtin Trigger */
    /* member  friend on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="friend"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_19_1", FK_COLUMNS="fri_no" */
    UPDATE friend
      SET
        /* %SetFK(friend,NULL) */
        friend.fri_no = NULL
      WHERE
        /* %JoinFKPK(friend,:%Old," = "," AND") */
        friend.fri_no = :old.mem_no;

    /* ERwin Builtin Trigger */
    /* member  chat on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20_1", FK_COLUMNS="mem_no" */
    UPDATE chat
      SET
        /* %SetFK(chat,NULL) */
        chat.mem_no = NULL
      WHERE
        /* %JoinFKPK(chat,:%Old," = "," AND") */
        chat.mem_no = :old.mem_no;


-- ERwin Builtin Trigger
END;
/


CREATE OR REPLACE TRIGGER SCOTT.tU_member AFTER UPDATE ON SCOTT.MEMBER for each row
-- ERwin Builtin Trigger
-- UPDATE trigger on member
DECLARE NUMROWS INTEGER;
BEGIN
  /* member  room_member on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="00033f69", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_17_1", FK_COLUMNS="mem_no" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.mem_no <> :new.mem_no
  THEN
    UPDATE room_member
      SET
        /* %SetFK(room_member,NULL) */
        room_member.mem_no = NULL
      WHERE
        /* %JoinFKPK(room_member,:%Old," = ",",") */
        room_member.mem_no = :old.mem_no;
  END IF;

  /* member  friend on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="friend"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_18_1", FK_COLUMNS="mem_no" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.mem_no <> :new.mem_no
  THEN
    UPDATE friend
      SET
        /* %SetFK(friend,NULL) */
        friend.mem_no = NULL
      WHERE
        /* %JoinFKPK(friend,:%Old," = ",",") */
        friend.mem_no = :old.mem_no;
  END IF;

  /* member  friend on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="friend"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_19_1", FK_COLUMNS="fri_no" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.mem_no <> :new.mem_no
  THEN
    UPDATE friend
      SET
        /* %SetFK(friend,NULL) */
        friend.fri_no = NULL
      WHERE
        /* %JoinFKPK(friend,:%Old," = ",",") */
        friend.fri_no = :old.mem_no;
  END IF;

  /* member  chat on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20_1", FK_COLUMNS="mem_no" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.mem_no <> :new.mem_no
  THEN
    UPDATE chat
      SET
        /* %SetFK(chat,NULL) */
        chat.mem_no = NULL
      WHERE
        /* %JoinFKPK(chat,:%Old," = ",",") */
        chat.mem_no = :old.mem_no;
  END IF;


-- ERwin Builtin Trigger
END;
/


CREATE OR REPLACE TRIGGER SCOTT.tD_room AFTER DELETE ON SCOTT.ROOM for each row
-- ERwin Builtin Trigger
-- DELETE trigger on room
DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin Trigger */
    /* room  room_member on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0001c2e0", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="room_no" */
    SELECT count(*) INTO NUMROWS
      FROM room_member
      WHERE
        /*  %JoinFKPK(room_member,:%Old," = "," AND") */
        room_member.room_no = :old.room_no;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete room because room_member exists.'
      );
    END IF;

    /* ERwin Builtin Trigger */
    /* room  chat on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="room_no" */
    SELECT count(*) INTO NUMROWS
      FROM chat
      WHERE
        /*  %JoinFKPK(chat,:%Old," = "," AND") */
        chat.room_no = :old.room_no;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete room because chat exists.'
      );
    END IF;


-- ERwin Builtin Trigger
END;
/


CREATE OR REPLACE TRIGGER SCOTT.tU_room AFTER UPDATE ON SCOTT.ROOM for each row
-- ERwin Builtin Trigger
-- UPDATE trigger on room
DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin Trigger */
  /* room  room_member on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="0002043f", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="room_no" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.room_no <> :new.room_no
  THEN
    SELECT count(*) INTO NUMROWS
      FROM room_member
      WHERE
        /*  %JoinFKPK(room_member,:%Old," = "," AND") */
        room_member.room_no = :old.room_no;
    IF (NUMROWS > 0)
    THEN 
      raise_application_error(
        -20005,
        'Cannot update room because room_member exists.'
      );
    END IF;
  END IF;

  /* ERwin Builtin Trigger */
  /* room  chat on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="room_no" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.room_no <> :new.room_no
  THEN
    SELECT count(*) INTO NUMROWS
      FROM chat
      WHERE
        /*  %JoinFKPK(chat,:%Old," = "," AND") */
        chat.room_no = :old.room_no;
    IF (NUMROWS > 0)
    THEN 
      raise_application_error(
        -20005,
        'Cannot update room because chat exists.'
      );
    END IF;
  END IF;


-- ERwin Builtin Trigger
END;
/


CREATE OR REPLACE TRIGGER SCOTT.tI_room_member BEFORE INSERT ON SCOTT.ROOM_MEMBER for each row
-- ERwin Builtin Trigger
-- INSERT trigger on room_member
DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin Trigger */
    /* room  room_member on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="0001eeb6", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="room_no" */
    SELECT count(*) INTO NUMROWS
      FROM room
      WHERE
        /* %JoinFKPK(:%New,room," = "," AND") */
        :new.room_no = room.room_no;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */
      
      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert room_member because room does not exist.'
      );
    END IF;

    /* ERwin Builtin Trigger */
    /* member  room_member on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_17_1", FK_COLUMNS="mem_no" */
    UPDATE room_member
      SET
        /* %SetFK(room_member,NULL) */
        room_member.mem_no = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM member
            WHERE
              /* %JoinFKPK(:%New,member," = "," AND") */
              :new.mem_no = member.mem_no
        ) 
        /* %JoinPKPK(room_member,:%New," = "," AND") */
         and room_member.room_seq = :new.room_seq;


-- ERwin Builtin Trigger
END;
/


CREATE OR REPLACE TRIGGER SCOTT.tU_room_member AFTER UPDATE ON SCOTT.ROOM_MEMBER for each row
-- ERwin Builtin Trigger
-- UPDATE trigger on room_member
DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin Trigger */
  /* room  room_member on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="0001dff2", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_4", FK_COLUMNS="room_no" */
  SELECT count(*) INTO NUMROWS
    FROM room
    WHERE
      /* %JoinFKPK(:%New,room," = "," AND") */
      :new.room_no = room.room_no;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update room_member because room does not exist.'
    );
  END IF;

  /* ERwin Builtin Trigger */
  /* member  room_member on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="room_member"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_17_1", FK_COLUMNS="mem_no" */
  SELECT count(*) INTO NUMROWS
    FROM member
    WHERE
      /* %JoinFKPK(:%New,member," = "," AND") */
      :new.mem_no = member.mem_no;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.mem_no IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update room_member because member does not exist.'
    );
  END IF;


-- ERwin Builtin Trigger
END;
/


ALTER TABLE SCOTT.CHAT
 DROP PRIMARY KEY CASCADE;

DROP TABLE SCOTT.CHAT CASCADE CONSTRAINTS;

CREATE TABLE SCOTT.CHAT
(
  CHAT_NO       NUMBER(10)                      NOT NULL,
  ROOM_NO       NUMBER(5)                       NOT NULL,
  CHAT_CONTENT  VARCHAR2(200 BYTE)              NOT NULL,
  CHAT_TIME     VARCHAR2(20 BYTE)               NOT NULL,
  MEM_NO        NUMBER(5)                       NOT NULL
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX SCOTT."XPK��ȭ" ON SCOTT.CHAT
(CHAT_NO)
LOGGING
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE OR REPLACE TRIGGER SCOTT.tI_chat BEFORE INSERT ON SCOTT.CHAT for each row
-- ERwin Builtin Trigger
-- INSERT trigger on chat
DECLARE NUMROWS INTEGER;
BEGIN
    /* ERwin Builtin Trigger */
    /* room  chat on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="0001c221", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="room_no" */
    SELECT count(*) INTO NUMROWS
      FROM room
      WHERE
        /* %JoinFKPK(:%New,room," = "," AND") */
        :new.room_no = room.room_no;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */
      
      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert chat because room does not exist.'
      );
    END IF;

    /* ERwin Builtin Trigger */
    /* member  chat on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20_1", FK_COLUMNS="mem_no" */
    UPDATE chat
      SET
        /* %SetFK(chat,NULL) */
        chat.mem_no = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM member
            WHERE
              /* %JoinFKPK(:%New,member," = "," AND") */
              :new.mem_no = member.mem_no
        ) 
        /* %JoinPKPK(chat,:%New," = "," AND") */
         and chat.chat_no = :new.chat_no;


-- ERwin Builtin Trigger
END;
/


CREATE OR REPLACE TRIGGER SCOTT.tU_chat AFTER UPDATE ON SCOTT.CHAT for each row
-- ERwin Builtin Trigger
-- UPDATE trigger on chat
DECLARE NUMROWS INTEGER;
BEGIN
  /* ERwin Builtin Trigger */
  /* room  chat on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="0001d489", PARENT_OWNER="", PARENT_TABLE="room"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_5", FK_COLUMNS="room_no" */
  SELECT count(*) INTO NUMROWS
    FROM room
    WHERE
      /* %JoinFKPK(:%New,room," = "," AND") */
      :new.room_no = room.room_no;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update chat because room does not exist.'
    );
  END IF;

  /* ERwin Builtin Trigger */
  /* member  chat on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="member"
    CHILD_OWNER="", CHILD_TABLE="chat"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20_1", FK_COLUMNS="mem_no" */
  SELECT count(*) INTO NUMROWS
    FROM member
    WHERE
      /* %JoinFKPK(:%New,member," = "," AND") */
      :new.mem_no = member.mem_no;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.mem_no IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update chat because member does not exist.'
    );
  END IF;


-- ERwin Builtin Trigger
END;
/


ALTER TABLE SCOTT.MEMBER ADD (
  CONSTRAINT "XPKȸ��"
  PRIMARY KEY
  (MEM_NO)
  USING INDEX SCOTT."XPKȸ��"
  ENABLE VALIDATE);

ALTER TABLE SCOTT.ROOM ADD (
  CONSTRAINT "XPK��"
  PRIMARY KEY
  (ROOM_NO)
  USING INDEX SCOTT."XPK��"
  ENABLE VALIDATE);

ALTER TABLE SCOTT.ROOM_MEMBER ADD (
  CONSTRAINT "XPK��������"
  PRIMARY KEY
  (ROOM_SEQ)
  USING INDEX SCOTT."XPK��������"
  ENABLE VALIDATE);

ALTER TABLE SCOTT.CHAT ADD (
  CONSTRAINT "XPK��ȭ"
  PRIMARY KEY
  (CHAT_NO)
  USING INDEX SCOTT."XPK��ȭ"
  ENABLE VALIDATE);

ALTER TABLE SCOTT.ROOM_MEMBER ADD (
  CONSTRAINT R_17_1 
  FOREIGN KEY (MEM_NO) 
  REFERENCES SCOTT.MEMBER (MEM_NO)
  ON DELETE SET NULL
  ENABLE VALIDATE,
  CONSTRAINT R_4 
  FOREIGN KEY (ROOM_NO) 
  REFERENCES SCOTT.ROOM (ROOM_NO)
  ENABLE VALIDATE);

ALTER TABLE SCOTT.CHAT ADD (
  CONSTRAINT R_20_1 
  FOREIGN KEY (MEM_NO) 
  REFERENCES SCOTT.MEMBER (MEM_NO)
  ON DELETE SET NULL
  ENABLE VALIDATE,
  CONSTRAINT R_5 
  FOREIGN KEY (ROOM_NO) 
  REFERENCES SCOTT.ROOM (ROOM_NO)
  ENABLE VALIDATE);
DROP PROCEDURE SCOTT.PROC_FRIEND_OPTION;

CREATE OR REPLACE PROCEDURE SCOTT.proc_friend_option(p_uid in varchar2, p_fid in varchar2,p_option in number, msg out varchar2)
                                                                                        
is

/*
MEM_ID   
MEM_NAME   
MEM_NICK  
MEM_GENDER  
MEM_PW 
MEM_HP 
MEM_PROFILE    
MEM_BACKGROUND  
*/
    mem_list MEMBER   %rowtype;--������̺�����(������Ʈ)
    fri_list FRIEND  %rowtype;
    v_option number;
    v_uno number;
    v_uid varchar2(30);
    v_fno number;
    v_fname varchar2(30);
    vc_fno number;

        cursor c_memlist
        is
        select MEM_NO,MEM_ID,MEM_NAME,MEM_NICK,MEM_GENDER,MEM_PW,MEM_HP,MEM_PROFILE,MEM_BACKGROUND
        from MEMBER;
        
        
        cursor c_frilist
        is
        select FRI_SEQ,FRI_NO,MEM_NO,FRIEND_NAME
        from FRIEND;
begin
       
    open c_memlist;
                 fetch c_memlist into mem_list.MEM_NO,
                                                  mem_list.MEM_ID,
                                                  mem_list.MEM_NAME,
                                                  mem_list.MEM_NICK,
                                                  mem_list.MEM_GENDER,
                                                  mem_list.MEM_PW,
                                                  mem_list.MEM_HP,
                                                  mem_list.MEM_PROFILE,
                                                  mem_list.MEM_BACKGROUND;
    open c_frilist;
                 fetch c_frilist into fri_list.FRI_SEQ,
                                                 fri_list.FRI_NO,
                                                 fri_list.MEM_NO,
                                                 fri_list.FRIEND_NAME; 
                 
    v_uid :=p_uid;
    v_option := p_option;
    
    select mem_no,mem_name into v_fno,v_fname from member where mem_id = p_fid;
    
    select mem_no into v_uno from member where mem_id = p_uid;
    
   -- select count(fri_no) into vc_fno from FRIEND where mem_no = v_uno and fri_no = v_fno group by fri_no;
    
    if(v_option =4) then--ģ���߰�
     
             insert into FRIEND  (FRI_SEQ,FRI_NO,MEM_NO,FRIEND_NAME)
            values(seq_friend.nextval,v_fno,v_uno,v_fname);
            msg := '�߰��Ǿ����ϴ�.';
      end if;

       if(v_option=5) then--ģ������
        DELETE FRIEND WHERE mem_no = v_uno and fri_no =v_fno; 
        msg := '�����Ǿ����ϴ�.';
          end if;
    
     close c_memlist;
     close c_frilist;
    commit;
   
end;
/

DROP PROCEDURE SCOTT.PROC_MEMBER_OPTION;

CREATE OR REPLACE PROCEDURE SCOTT.proc_member_option(p_uid in varchar2,p_uname in varchar2,
                                                                                        p_unick in varchar2,p_ugen in varchar2,p_upw in varchar2,
                                                                                        p_uhp in varchar2,p_upro in varchar2,p_uback in varchar2,
                                                                                        p_option in number, msg out varchar2)
                                                                                        
is

/*
MEM_ID   
MEM_NAME   
MEM_NICK  
MEM_GENDER  
MEM_PW 
MEM_HP 
MEM_PROFILE    
MEM_BACKGROUND  
*/
    mem_list MEMBER   %rowtype;--������̺�����(������Ʈ)
    v_option number;
    v_uno number;
    v_ID varchar2(50);   
    v_NAME  varchar2(50); 
    v_NICK  varchar2(50);
    v_GENDER  varchar2(10);
    v_PW varchar2(10);
    v_HP varchar2(50);
    v_PROFILE    varchar2(150);
    v_BACKGROUND  varchar2(150);

        cursor c_memlist
        is
        select MEM_NO,MEM_ID,MEM_NAME,MEM_NICK,MEM_GENDER,MEM_PW,MEM_HP,MEM_PROFILE,MEM_BACKGROUND
        from MEMBER;
begin
       
    open c_memlist;
                 fetch c_memlist into mem_list.MEM_NO,
                                                  mem_list.MEM_ID,
                                                  mem_list.MEM_NAME,
                                                  mem_list.MEM_NICK,
                                                  mem_list.MEM_GENDER,
                                                  mem_list.MEM_PW,
                                                  mem_list.MEM_HP,
                                                  mem_list.MEM_PROFILE,
                                                  mem_list.MEM_BACKGROUND;
    v_uno       :=  mem_list.MEM_NO;                                          
    v_ID        :=  p_uid;
    v_NAME      :=  p_uname;
    v_NICK      :=  p_unick;
    v_GENDER    :=  p_ugen;
    v_PW        :=  p_upw;
    v_HP        :=  p_uhp;
    v_PROFILE   :=  p_upro;
    v_BACKGROUND:=  p_uback;
    v_option    :=  p_option;

    if(v_option =1) then--ȸ������
      insert into MEMBER  (MEM_NO,MEM_ID,MEM_NAME,MEM_GENDER,MEM_PW,MEM_HP)
                        values(seq_member.nextval,p_uid,p_uname,p_ugen,p_upw,p_uhp);
      msg := '������ �Ϸ�Ǿ����ϴ�.';
    end if;
       if(v_option=2) then--ȸ����������
        select mem_no into v_uno from member where mem_id = p_uid; 
        
        update MEMBER
            set MEM_NAME = p_uname
        where MEM_NO =v_uno;
        
        update MEMBER
            set MEM_NICK = p_unick
        where MEM_NO =v_uno;      
        
        update MEMBER
            set MEM_GENDER = p_ugen
        where MEM_NO =v_uno;
        
        update MEMBER
            set MEM_HP = p_uhp
        where MEM_NO =v_uno; 
        
        update MEMBER
            set MEM_PW = p_upw
        where MEM_NO =v_uno;
        
        if(p_upro is null) then
            select mem_profile into v_PROFILE from member where mem_no = v_uno; 
        
            update MEMBER
                set MEM_PROFILE = v_PROFILE
            where MEM_NO =v_uno;
     
        else
            update MEMBER
                set MEM_PROFILE = p_upro
            where MEM_NO =v_uno;
        
        end if;
        
        if(p_uback is null) then
            select MEM_BACKGROUND into v_BACKGROUND from member where mem_no = v_uno;
         
            update MEMBER
                set MEM_BACKGROUND = v_BACKGROUND
            where MEM_NO =v_uno;
        
        else
            update MEMBER
                set MEM_BACKGROUND = p_uback
            where MEM_NO =v_uno;
        end if;
        
        msg := '������ �����Ǿ����ϴ�.';
       end if;

    close c_memlist;
    commit;
end;
/

DROP PROCEDURE SCOTT.PROC_MEMBER_OVERLAP;

CREATE OR REPLACE PROCEDURE SCOTT.proc_member_overlap(p_uid in varchar2, msg out number)
                                                                                        
is

    mem_list MEMBER   %rowtype;--������̺�����(������Ʈ)
    v_ID varchar2(50);   
    v_count number;

        cursor c_memlist
        is
        select MEM_NO,MEM_ID,MEM_NAME,MEM_NICK,MEM_GENDER,MEM_PW,MEM_HP,MEM_PROFILE,MEM_BACKGROUND
        from MEMBER;
begin
       
    open c_memlist;
                 fetch c_memlist into mem_list.MEM_NO,
                                                  mem_list.MEM_ID,
                                                  mem_list.MEM_NAME,
                                                  mem_list.MEM_NICK,
                                                  mem_list.MEM_GENDER,
                                                  mem_list.MEM_PW,
                                                  mem_list.MEM_HP,
                                                  mem_list.MEM_PROFILE,
                                                  mem_list.MEM_BACKGROUND;
    v_ID :=p_uid;
    select count(mem_id) into v_count from member where mem_id = p_uid;


    if(v_count =1) then-- �ߺ�
       msg := '1';
        end if;
       if(v_count=0) then--�ߺ��ƴ�
       msg := '0';
          end if;

     close c_memlist;

   
end;
/

DROP PROCEDURE SCOTT.PROC_ROOM_CREATE;

CREATE OR REPLACE PROCEDURE SCOTT.proc_room_create(p_rtitle in varchar2,msg out number)
IS
    v_rtitle varchar2(100);
    v_rno number(5);
BEGIN
    IF(p_rtitle IS NULL) THEN
        v_rtitle := '�������';
    ELSE
        v_rtitle := p_rtitle;    
    END IF;
    INSERT INTO room(room_no, room_starttime, room_title) VALUES(seq_room.nextval, to_char(sysdate,'YYYY-MM-DD hh:mm:ss') , v_rtitle);
    SELECT room_no INTO v_rno FROM room WHERE rownum = 1 ORDER BY room_no desc;
    msg := v_rno;
END;
/
DROP INDEX SCOTT.FRI_OVERLAP_PK;

CREATE UNIQUE INDEX SCOTT.FRI_OVERLAP_PK ON SCOTT.FRIEND
(MEM_NO, FRI_NO)
LOGGING
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;
DROP SEQUENCE SCOTT.SEQ_CHAT;

CREATE SEQUENCE SCOTT.SEQ_CHAT
  START WITH 561
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;


DROP SEQUENCE SCOTT.SEQ_FRIEND;

CREATE SEQUENCE SCOTT.SEQ_FRIEND
  START WITH 141
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;


DROP SEQUENCE SCOTT.SEQ_MEMBER;

CREATE SEQUENCE SCOTT.SEQ_MEMBER
  START WITH 61
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;


DROP SEQUENCE SCOTT.SEQ_ROOM;

CREATE SEQUENCE SCOTT.SEQ_ROOM
  START WITH 101
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;


DROP SEQUENCE SCOTT.SEQ_ROOM_MEMBER;

CREATE SEQUENCE SCOTT.SEQ_ROOM_MEMBER
  START WITH 81
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 20
  NOORDER;
